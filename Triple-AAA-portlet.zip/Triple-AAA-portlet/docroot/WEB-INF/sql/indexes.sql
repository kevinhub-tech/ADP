create index IX_CE4F5412 on KV_Customer (groupId);
create index IX_C6EEC31C on KV_Customer (uuid_);
create index IX_3E31778C on KV_Customer (uuid_, companyId);
create unique index IX_708A710E on KV_Customer (uuid_, groupId);

create index IX_EC347392 on KV_Services (groupId);
create index IX_3295C29C on KV_Services (uuid_);
create index IX_FB57C80C on KV_Services (uuid_, companyId);
create unique index IX_C0AE18E on KV_Services (uuid_, groupId);