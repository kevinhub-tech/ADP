/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.wkp.aaa.service.impl;

import java.util.Date;
import java.util.List;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ResourceConstants;
import com.liferay.portal.model.User;
import com.liferay.portal.service.ServiceContext;
import com.wkp.aaa.ServicesNameException;
import com.wkp.aaa.ServicesPriceException;
import com.wkp.aaa.model.Services;
import com.wkp.aaa.service.base.ServicesLocalServiceBaseImpl;



public class ServicesLocalServiceImpl extends ServicesLocalServiceBaseImpl {
	//Finder Method 
	public List<Services> getServicexs(long groupId) throws SystemException{
		return servicesPersistence.findByServicesFinder(groupId);
	}
	
	//Finder Method with pagination
	public List<Services> getServicexs(long groupId, int start, int end) throws SystemException{
		return servicesPersistence.findByServicesFinder(groupId, start, end);
	}
	
	//Validation method
	protected void validate(String serviceName, String servicesPrice) throws PortalException{
		if(Validator.isNull(serviceName))
			throw new ServicesNameException();
		
		if(Validator.isNull(servicesPrice))
			throw new ServicesPriceException();
	}
	
	//Add Pizza Method
	public Services addServices(long userId, String servicesName, String servicesPrice, String servicesDesc, ServiceContext serviceContext) throws PortalException, SystemException{
		
		//Scope Column(uuid, groupId, companyId)
		//User Column (userId, userName)
		//Audit Column (createDate, modifiedDate)
		
		User user = userPersistence.findByPrimaryKey(userId);
		Date now = new Date();
		long servicesId = counterLocalService.increment();
		
		Services services = servicesPersistence.create(servicesId);
		
		services.setUuid(serviceContext.getUuid());
		services.setGroupId(serviceContext.getScopeGroupId());
		services.setCompanyId(serviceContext.getCompanyId());
		
		services.setUserId(user.getUserId());
		services.setUserName(user.getFullName());
		
		services.setCreateDate(serviceContext.getCreateDate(now));
		services.setModifiedDate(serviceContext.getModifiedDate(now));
		
		services.setServicesName(servicesName);
		services.setServicesPrice(servicesPrice);
		services.setServicesDesc(servicesDesc);
		
		services.setExpandoBridgeAttributes(serviceContext);
		
		servicesPersistence.update(services);
		resourceLocalService.addResources(user.getCompanyId(), serviceContext.getScopeGroupId(), userId, Services.class.getName(), servicesId, false, true, true);
		
		return services;
	}

	public Services updateServices(long userId, long servicesId, String servicesName, String servicesPrice, String servicesDesc, ServiceContext serviceContext) throws PortalException, SystemException {
		//get current pizzaId 
		Services services = servicesPersistence.findByPrimaryKey(servicesId);
		
		//set modified date
		services.setModifiedDate(serviceContext.getModifiedDate());
		
		//allows to edit or update pizzaName, pizzaPrice, pizzaIngredients
		services.setServicesName(servicesName);
		services.setServicesPrice(servicesPrice);
		services.setServicesDesc(servicesDesc);
		
		services.setExpandoBridgeAttributes(serviceContext);
		
		servicesPersistence.update(services);
		User user = userPersistence.findByPrimaryKey(userId);
		
		resourceLocalService.updateResources(
				user.getCompanyId(), serviceContext.getScopeGroupId(), Services.class.getName(), servicesId,
				serviceContext.getGroupPermissions(),
				serviceContext.getGuestPermissions());
		return services;
	}


	public Services deleteServices(long userId, long servicesId, ServiceContext serviceContext)
			throws PortalException, SystemException {
		//Get pizzaId which we want to delete
		Services services = getServices(servicesId);
		//Call deletePizza method by passing current pizzaId which want to delete
		services =  deleteServices(servicesId);
		//return current SERVICES object
		resourceLocalService.deleteResource(
				serviceContext.getCompanyId(), Services.class.getName(),
				ResourceConstants.SCOPE_INDIVIDUAL, servicesId);
	
		return services;
	}
	
}